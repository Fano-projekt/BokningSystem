﻿namespace BokningSystem.Models
{
    public class AdminDashboardViewModel
    {
        public List<LedigaTider> LedigaTider { get; set; }
        public List<Bokning> Bokningar { get; set; }
    }
}
